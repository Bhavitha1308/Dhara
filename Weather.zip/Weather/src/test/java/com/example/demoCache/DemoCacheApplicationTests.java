package com.example.demoCache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
