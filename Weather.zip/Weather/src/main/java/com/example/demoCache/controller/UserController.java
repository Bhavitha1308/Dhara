package com.example.demoCache.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoCache.services.DataService;
import com.example.demoCache.services.TimeService;
import com.example.demoCache.services.WeatherService;

@RestController
@CrossOrigin(originPatterns = "http://localhost:5173")
public class UserController 
{
    @Autowired
    DataService service;
    @Autowired
    TimeService tservice;
    @Autowired
    WeatherService wservice;

   @GetMapping("/data")
   public String getData(@RequestParam String query)
   {
      return  this.service.getData(query);
   }

   @GetMapping("/time")
   String getTime(@RequestParam String region)
   {
       return this.tservice.getTime(region);
   }


//    private final WeatherService WeatherService;

    // public WeatherController(WeatherService weatherService) {
    //     this.weatherService = weatherService;
    // }

    @GetMapping("/city/{city}")
    public String getWeather(@PathVariable String city) {
        System.out.println("-----------------------------------------");
        return this.wservice.getWeatherByCity(city);
    }
    

} 
