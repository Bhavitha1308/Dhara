package com.example.Project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Project.model.Users;
import com.example.Project.repository.BookRepository;
import com.example.Project.repository.UserRepository;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
public class UserController 
{
     @Autowired
    UserRepository ur;

     @Autowired
    BookRepository br;

    @PostMapping("/register")
    String Register(@RequestBody Users u)
    {
       Users result= this.ur.findByUsername(u.getUsername());
        if(result !=null)
      {
        return "username already exist";

      }
      this.ur.save(u);
      return "registration successfully done";
    }

     @PostMapping("/login")
public String Login(@RequestBody Users u) {
    Users result = this.ur.findByUsername(u.getUsername());
    if (result != null && result.getPassword().equals(u.getPassword())) {
        return "Login Successfully done";
    }
    return "invalid username or password"; 
   }
}
