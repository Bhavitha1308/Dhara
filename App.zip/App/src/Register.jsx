import axios from "axios";
import { useState } from "react"


function Register()
{
    const [form,setform]=useState(
        {
            username:"",
            email:"",
            password:""
        }
    )    
   
    const submitform = async (e) =>
    {
       e.preventDefault()
         const response= await axios.post("http://localhost:8080/register",form)
         alert(response.data)
    }
    const changedata=(e) =>
    {
        setform({...form,[e.target.name]:e.target.value})
    }
    
    return(
        <>
           <h1>registration page </h1>
           <p>{form.username}</p>
           <p>{form.email}</p>
           <p>{form.password}</p>
           <form onSubmit={submitform}>
                 <input onChange={changedata} type="text" name="username" placeholder="create username"/>
                 <input onChange={changedata} type="email" name="email" placeholder="enter email"/> 
                 <input onChange={changedata} type="password" name="password" placeholder="create password"/>
                 <button type="submit">Register</button>
           </form>
        </>
    )
}
export default Register