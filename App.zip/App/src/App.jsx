import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "./Home";
import Register from "./Register";
import Login from "./Login";
import Admin from "./Admin";
import Library from "./Library";
import AuthorBook from "./Books/AuthorBook";
import AddBook from "./Books/AddBook";
import Bookdata from "./Books/Bookdata";
import BookList from "./Books/BookList";


function App()
{
  return(
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/reg" element={<Register/>}/>
          <Route path="/log" element={<Login/>}/>
          <Route path="/admin" element={<Admin/>}/>
          <Route path="/library" element={<Library/>}/>
          <Route path="/abook" element={<AddBook/>}/>
          <Route path="/vauthorbook" element={<AuthorBook/>}/>
          <Route path="/booklist" element={<BookList/>}/>
          <Route path="/bookdata" element={<Bookdata/>}/>
          
        </Routes>
      </BrowserRouter>
    </>
  )
}
export default App