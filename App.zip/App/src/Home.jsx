import { Link } from "react-router-dom"; 

function Home() {
    return (
        <>
            <h1>Hi, I am at Home..</h1>
            <p><Link to="/reg">Click here to Register</Link></p>
            <p><Link to="/log">Click here to Login</Link></p>
        </>
    );
}

export default Home;
