import axios from "axios";
import { useState } from "react"
import { useNavigate } from "react-router-dom";


function Login()
{
    const navigate=useNavigate()
    const [form,setform]=useState(
        {
            username:"",
            password:""
        }
    )    
    const changedata=(e) =>
    {
        setform({...form,[e.target.name]:e.target.value})
    }
    
    const submitform = async (e) =>
    {
       e.preventDefault()
         const response= await axios.post("http://localhost:8080/login",form)
         alert(response.data)
         navigate("/admin")
    }

    return(
        <>
           <h1>Login page </h1>
           <p>{form.username}</p>
           <p>{form.password}</p>
           <form onSubmit={submitform}>
               <input onChange={changedata} type="text" name="username" placeholder="create username"/>
               <input onChange={changedata} type="password" name="password" placeholder="create password"/>
               <button type="login">Login</button>
           </form>
        </>
    )
}
export default Login