function BookList()
{
    return(
        <>
        <h1>Add a book</h1>
        </>
    )
}
export default BookList;